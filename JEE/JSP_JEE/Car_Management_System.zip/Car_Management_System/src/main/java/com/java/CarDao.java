package com.java;

interface CarDao {

		void saveCar(Car car);
		void CarUpdate(Car car);
		void CarDelete(Car car);
		void findCar(Car car);
}
